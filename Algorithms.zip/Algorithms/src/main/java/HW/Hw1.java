package HW;

public class Hw1 {
    public static void main(String[] args) {

        //Написать псевдокод для алгоритма: сложить три числа и
        //вывести сумму.
        //Реализовать алгоритм в коде.

        //Start
        //Number input, a,b,c;
        //sum = a+b+c;
        //return sum
        //end

       int result = getSumof3numbers(2,2,2);
        System.out.println(result);

        //Написать псевдокод для алгоритма линейного поиска
        //Реализовать алгоритм в коде

        //Start
        //Search int x;
        //If int x == arr[i]; then arr[i] = int searchElem and
        //return searchElem;
        //else search arr.lenght
        //End

        int[] arrTest = {11,12,332,441,22,13,7};
        int searchElem = 7;
        boolean found = false;

        for (int i = 0; i < arrTest.length; i++){
            if (arrTest[i] == searchElem){
                arrTest[i] = searchElem;
                System.out.println("Search element found at index " + arrTest[i]);
                found = true;
                break;
            }
        }
        if (!found){
            System.out.println("Search element not found");
        }


    }
    public static int getSumof3numbers(int a, int b, int c){
        int sum = a + b + c;
        return sum;

    }

}
