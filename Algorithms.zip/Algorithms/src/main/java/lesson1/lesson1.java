package lesson1;

public class lesson1 {
    public static void main(String[] args) {


        int [] arr = {1,22,32,354,1212,};

        //Start
        //write int number = 0;
        // input num
        // if num < 0 then num + number and output number "число отрицательное"
        //else output number "число положительное";
        // end

    }
}
